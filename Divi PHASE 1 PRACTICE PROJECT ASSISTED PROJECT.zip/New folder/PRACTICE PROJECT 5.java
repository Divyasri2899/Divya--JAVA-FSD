package listsoflinked;

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class SinglyLinkedList {
	
	private Node head;

    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public void deleteFirstOccurrence(int key) {
        if (head == null) {
            System.out.println("List is empty. Cannot delete.");
            return;
        }

        if (head.data == key) {
            head = head.next;
            System.out.println("First occurrence of " + key + " deleted.");
            return;
        }

        Node current = head;
        Node prev = null;

        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }

        if (current == null) {
            System.out.println("Key " + key + " not found in the list.");
            return;
        }

        prev.next = current.next;
        System.out.println("First occurrence of " + key + " deleted.");
    }


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SinglyLinkedList linkedList = new SinglyLinkedList();

        // Insert some elements
        linkedList.insert(1);
        linkedList.insert(2);
        linkedList.insert(3);
        linkedList.insert(4);

        System.out.println("Original Linked List:");
        linkedList.display();

        // Delete the first occurrence of key 2
        linkedList.deleteFirstOccurrence(2);

        System.out.println("Linked List after deletion:");
        linkedList.display();
		
		

	}

}
