package list;

class Node {
    int data;
    Node prev;
    Node next;

    Node(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

public class DoublyLinkedList {
	private Node head;
    private Node tail;

    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            newNode.prev = tail;
            tail.next = newNode;
            tail = newNode;
        }
    }

    public void traverseForward() {
        System.out.println("Traversing in the forward direction:");
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public void traverseBackward() {
        System.out.println("Traversing in the backward direction:");
        Node current = tail;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DoublyLinkedList doublyList = new DoublyLinkedList();

        // Insert some elements
        doublyList.insert(1);
        doublyList.insert(3);
        doublyList.insert(99);
        doublyList.insert(41);
        doublyList.insert(43);
        doublyList.insert(87);
        doublyList.insert(62);
        doublyList.insert(102);
        doublyList.insert(007);

        // Traverse in forward direction
        doublyList.traverseForward();

        // Traverse in backward direction
        doublyList.traverseBackward();

	}

}
