package com;

public class MergrSort {

	 public static void mergeSort(int[] array) {
	        int n = array.length;

	        if (n > 1) {
	            int mid = n / 2;

	            // Split the array into two halves
	            int[] leftArray = new int[mid];
	            int[] rightArray = new int[n - mid];

	            System.arraycopy(array, 0, leftArray, 0, mid);
	            System.arraycopy(array, mid, rightArray, 0, n - mid);

	            // Recursive calls to sort the two halves
	            mergeSort(leftArray);
	            mergeSort(rightArray);

	            // Merge the sorted halves
	            merge(array, leftArray, rightArray);
	        }
	    }

	    public static void merge(int[] array, int[] leftArray, int[] rightArray) {
	        int leftSize = leftArray.length;
	        int rightSize = rightArray.length;

	        int i = 0, j = 0, k = 0;

	        // Merge the two halves back into the original array
	        while (i < leftSize && j < rightSize) {
	            if (leftArray[i] <= rightArray[j]) {
	                array[k++] = leftArray[i++];
	            } else {
	                array[k++] = rightArray[j++];
	            }
	        }

	        // Copy remaining elements of leftArray, if any
	        while (i < leftSize) {
	            array[k++] = leftArray[i++];
	        }

	        // Copy remaining elements of rightArray, if any
	        while (j < rightSize) {
	            array[k++] = rightArray[j++];
	        }
	    }

	    public static void printArray(int[] array) {
	        for (int value : array) {
	            System.out.print(value + " ");
	        }
	        System.out.println();
	    }

	    public static void main(String[] args) {
	        int[] array = {38, 27, 43, 3, 9, 82, 10};
	        System.out.println("Original array:");
	        printArray(array);

	        // Apply merge sort
	        mergeSort(array);

	        System.out.println("Sorted array:");
	        printArray(array);

	}

}
