package list;

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class SortedCircularLinkedList {
	
	private Node head;

    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            head.next = head; // Make it circular
        } else if (data <= head.data) {
            // If the new data is less than or equal to the head data,
            // insert the new node at the beginning
            Node last = getLastNode();
            newNode.next = head;
            head = newNode;
            last.next = head; // Update the last node to point to the new head
        } else {
            // Insert the new node at the appropriate position to maintain the sorted order
            Node current = head;
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    private Node getLastNode() {
        Node last = head;
        while (last.next != head) {
            last = last.next;
        }
        return last;
    }

    public void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SortedCircularLinkedList circularList = new SortedCircularLinkedList();

        // Insert some elements
        circularList.insert(2);
        circularList.insert(6);
        circularList.insert(1);
        circularList.insert(7);

        System.out.println("Original Sorted Circular Linked List:");
        circularList.display();

        // Insert a new element (e.g., 5)
        circularList.insert(5);

        System.out.println("Sorted Circular Linked List after insertion:");
        circularList.display();

	}

}
